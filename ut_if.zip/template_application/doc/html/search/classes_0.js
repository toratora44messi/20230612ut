var searchData=
[
  ['calc_6',['Calc',['../struct_calc.html',1,'']]]
];
