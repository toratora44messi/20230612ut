# include "rsc.h"

rsc::EDataDBType rsc::fgDataDBType = eRscDataDB_X;  // デフォルト値を適切な値に修正

rsc::EDataDBType rsc::getDataDBType()
{
    return rsc::fgDataDBType;
}


bool rsc::setDataDBType(EDataDBType dataDBType)
{
    if (dataDBType >= eRscDataDB_Max){  // 
        rsc::fgDataDBType = eRscDataDB_Max;
        return false;
    }

    rsc::fgDataDBType = dataDBType;
    return true;
}
