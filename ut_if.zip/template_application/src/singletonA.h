#ifndef SINGLETON_A_H
#define SINGLETON_A_H

class ISingletonA {
public:
    enum EFunctiuonType {
        eFunctonType_B,
        eFunctonType_C,
        eFunctonType_Max
    };
    virtual ~ISingletonA() {}
    virtual ISingletonA::EFunctiuonType shoudlFuncitonCall() = 0;
};

class singletonA : public ISingletonA {
private:
    singletonA();
public:
    ~singletonA();
    static singletonA* createInstance();
    static singletonA* getIntance();
    EFunctiuonType shoudlFuncitonCall();
private:
    static singletonA* fgA_Obj;
};

#endif // SINGLETON_A_H
