#include "singletonB.h"
#include <string.h>

singletonB* singletonB::fgB_Obj = 0;

singletonB::singletonB(/* args */)
    : fDB_Num(0)
{
}

singletonB::~singletonB()
{
}

singletonB* singletonB::createInstance()
{
    if (fgB_Obj != 0) {
        return fgB_Obj;
    }

    fgB_Obj = new singletonB();

    return fgB_Obj;
}

singletonB* singletonB::getIntance()
{
    return fgB_Obj;
}
    
bool singletonB::setDB(int num)
{
    fDB_Num = num;
    return true;
}

int singletonB::getNum()
{
    return fDB_Num;
}