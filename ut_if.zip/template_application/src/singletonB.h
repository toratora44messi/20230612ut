#ifndef SINGLETON_B_H
#define SINGLETON_B_H

class ISingletonB {
public:
    virtual ~ISingletonB() {}
    virtual bool setDB(int num) = 0;
    virtual int getNum() = 0;
};

class singletonB : public ISingletonB {
private:
    singletonB(/* args */);
public:
    ~singletonB();
    static singletonB* createInstance();
    static singletonB* getIntance();
    bool setDB(int num);
    int getNum();
private:
    static singletonB* fgB_Obj;
    int fDB_Num;
};

#endif // SINGLETON_B_H
