#ifndef SINGLETON_C_H
#define SINGLETON_C_H

class ISingletonC
{
public:
    virtual ~ISingletonC() {}
    virtual bool setDB(int num) = 0;
    virtual int getNum() = 0;
};

class singletonC
    : ISingletonC
{
private:
    singletonC(/* args */);
public:
    ~singletonC();
    static singletonC* createInstance();
    static singletonC* getIntance();
    bool setDB(int num);
    int getNum();

private:
    static singletonC* fgC_Obj;
    int fDB_Num;
};


#endif //SINGLETON_C_H