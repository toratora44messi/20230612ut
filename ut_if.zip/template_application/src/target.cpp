#include "target.h"
#include <stdio.h>

target::target(ISingletonA* aObj, ISingletonB* bObj, ISingletonC* cObj)
    : fAObj(aObj), 
    fBObj(bObj), 
    fCObj(cObj)
{
        printf("aaa");
}

target::~target()
{
}

target::EType target::set(int num){

    singletonA::EFunctiuonType funcType = fAObj->shoudlFuncitonCall();
    target::EType type = target::eType_UnKnown;
    switch (funcType)
    {
    case singletonA::eFunctonType_B:
        fBObj->setDB(num);
        type = target::eType_B;
        break;
    case singletonA::eFunctonType_C:
        fCObj->setDB(num);
        type = target::eType_C;
        break;
    default:
        printf("target::eType_UnKnown");
        type = target::eType_UnKnown;
        break;
    }
    return type;
}
