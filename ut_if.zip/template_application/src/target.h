#ifndef TARGET_H
#define TARGET_H
#include "singletonA.h"
#include "singletonB.h"
#include "singletonC.h"
class target
{
public:
    enum EType{
        eType_B,
        eType_C,
        eType_UnKnown
    };
    target(ISingletonA* aObj, ISingletonB* bObj, ISingletonC* cObj);
    ~target();
    EType set(int num);    //return : set funciton type

private:
    ISingletonA* fAObj;
    ISingletonB* fBObj;
    ISingletonC* fCObj;
};
#endif //TARGET_H