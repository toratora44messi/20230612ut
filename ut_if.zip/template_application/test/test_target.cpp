#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "rsc.h"
#include "target.h"

// モッククラスの定義
class MockSingletonA : public ISingletonA {
public:
    MOCK_METHOD(singletonA::EFunctiuonType, shoudlFuncitonCall, (), (override));
};

class MockSingletonB : public ISingletonB {
public:
    MOCK_METHOD(bool, setDB, (int num), (override));
    MOCK_METHOD(int, getNum, (), (override));
};

class MockSingletonC : public ISingletonC {
public:
    MOCK_METHOD(bool, setDB, (int num), (override));
    MOCK_METHOD(int, getNum, (), (override));
};

// テストフィクスチャクラス
class TargetTest : public ::testing::Test {
protected:
    virtual void SetUp() {
        // テスト前の初期化処理
        singletonA::createInstance();
        singletonB::createInstance();
        singletonC::createInstance();
    }

    virtual void TearDown() {
        // テスト後のクリーンアップ処理
        delete singletonA::getIntance();
        delete singletonB::getIntance();
        delete singletonC::getIntance();
    }
};

// target::set()のテスト
TEST_F(TargetTest, SetTest) {
    // Mockクラスのインスタンスを作成
    MockSingletonA mockSingletonA;
    MockSingletonB mockSingletonB;
    MockSingletonC mockSingletonC;

    // モックの動作を設定
    EXPECT_CALL(mockSingletonA, shoudlFuncitonCall())
        .WillOnce(::testing::Return(singletonA::eFunctonType_B));
    EXPECT_CALL(mockSingletonB, setDB(123))
        .WillOnce(::testing::Return(true));
    EXPECT_CALL(mockSingletonB, getNum())
        .WillOnce(::testing::Return(123));


  target t(&mockSingletonA, &mockSingletonB, &mockSingletonC);  // コンストラクタ呼び出し

    // rscクラスのデータベースタイプを設定
    rsc::setDataDBType(rsc::eRscDataDB_X);

    // データベースタイプがeRscDataDB_Xの場合
    target::EType result1 = t.set(123);
    EXPECT_EQ(result1, target::eType_B);
    EXPECT_EQ(mockSingletonB.getNum(), 123);  // 正しくデータが設定されているか確認
}

int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
