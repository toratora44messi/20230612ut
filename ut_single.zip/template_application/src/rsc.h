#ifndef RSC_H
#define RSC_H

class rsc
{
public:
    enum EDataDBType{
        eRscDataDB_X,
        eRscDataDB_Y,
        eRscDataDB_Z,
        eRscDataDB_Max
    };

    static EDataDBType getDataDBType();
    static bool setDataDBType(EDataDBType dataDBType);
public:
    static EDataDBType fgDataDBType;
};

#endif // RSC_H