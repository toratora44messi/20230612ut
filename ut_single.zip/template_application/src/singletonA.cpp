#include "rsc.h"
#include "singletonA.h"
#include <stdio.h>

singletonA* singletonA::fgA_Obj = 0;

singletonA::singletonA(/* args */) 
{
}

singletonA::~singletonA()
{
}

singletonA* singletonA::createInstance()
{
    if (fgA_Obj != 0) {
        return fgA_Obj;
    }

    fgA_Obj = new singletonA();

    return fgA_Obj;
}

singletonA* singletonA::getIntance()
{
    return fgA_Obj;
}

singletonA::EFunctiuonType singletonA::shoudlFuncitonCall()
{
    rsc::EDataDBType dataDBType = rsc::getDataDBType();
    singletonA::EFunctiuonType funcType = singletonA::eFunctonType_Max;

    switch (dataDBType)
    {
    case rsc::eRscDataDB_X:
        funcType = singletonA::eFunctonType_B;
        break;
    case rsc::eRscDataDB_Y:
    case rsc::eRscDataDB_Z:
        funcType = singletonA::eFunctonType_C;
        break;       
    default:
        printf("default");
        funcType = singletonA::eFunctonType_Max;
        break;
    }

    return funcType;
}


