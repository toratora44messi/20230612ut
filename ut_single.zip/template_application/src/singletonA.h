#ifndef SINGLETON_A_H
#define SINGLETON_A_H
class singletonA
{
private:
    singletonA(/* args */);
public:
    enum EFunctiuonType{
        eFunctonType_B,
        eFunctonType_C,
        eFunctonType_Max
    };

    ~singletonA();
    static singletonA* createInstance();
    static singletonA* getIntance();
    EFunctiuonType shoudlFuncitonCall();
private:
    static singletonA* fgA_Obj;
};

#endif // SINGLETON_A_H