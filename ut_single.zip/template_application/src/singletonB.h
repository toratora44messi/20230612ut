#ifndef SINGLETON_B_H
#define SINGLETON_B_H

class singletonB
{
private:
    singletonB(/* args */);
public:
    ~singletonB();
    static singletonB* createInstance();
    static singletonB* getIntance();
    bool setDB(int num);
    int getNum();
private:
    static singletonB* fgB_Obj;
    int fDB_Num;
};
#endif //SINGLETON_B_H
