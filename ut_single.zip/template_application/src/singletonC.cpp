#include "singletonC.h"

singletonC* singletonC::fgC_Obj = 0;

singletonC::singletonC(/* args */)
    : fDB_Num(0)
{
}

singletonC::~singletonC()
{
}

singletonC* singletonC::createInstance()
{
    if (fgC_Obj != 0) {
        return fgC_Obj;
    }

    fgC_Obj = new singletonC();

    return fgC_Obj;
}

singletonC* singletonC::getIntance()
{
    return fgC_Obj;
}

bool singletonC::setDB(int num)
{
    fDB_Num = num;
    return true;
}

int singletonC::getNum()
{
    return fDB_Num;
}