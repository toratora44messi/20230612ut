#include "target.h"
#include "singletonA.h"
#include "singletonB.h"
#include "singletonC.h"
#include <stdio.h>

target::target()
{
}

target::~target()
{
}

target::EType target::set(int num){

    singletonA* instance = singletonA::getIntance(); 
    singletonA::EFunctiuonType funcType = instance->shoudlFuncitonCall();
    target::EType type = target::eType_UnKnown;
    switch (funcType)
    {
    case singletonA::eFunctonType_B:
        singletonB::getIntance()->setDB(num);
        type = target::eType_B;
        break;
    case singletonA::eFunctonType_C:
        singletonC::getIntance()->setDB(num);
        type = target::eType_C;
        break;
    default:
        printf("target::eType_UnKnown");
        type = target::eType_UnKnown;
        break;
    }
    return type;
}
