#ifndef TARGET_H
#define TARGET_H

class target
{
private:
/* data */
public:
    enum EType{
        eType_B,
        eType_C,
        eType_UnKnown
    };

    target();
    ~target();
    EType set(int num);    //return : set funciton type
};
#endif //TARGET_H