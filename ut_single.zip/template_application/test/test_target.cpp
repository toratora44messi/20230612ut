#include <gtest/gtest.h>
#include "rsc.h"
#include "target.h"
#include "singletonA.h"
#include "singletonB.h"
#include "singletonC.h"


// テストフィクスチャクラス
class TargetTest : public ::testing::Test {
protected:
  virtual void SetUp() {
    // テスト前の初期化処理
    singletonA::createInstance();
    singletonB::createInstance();
    singletonC::createInstance();
  }

  virtual void TearDown() {
    // テスト後のクリーンアップ処理
    delete singletonA::getIntance();
    delete singletonB::getIntance();
    delete singletonC::getIntance();
  }
};

// target::set()のテスト
TEST_F(TargetTest, SetTest) {
  target t;

  // rscクラスのデータベースタイプを設定
  rsc::setDataDBType(rsc::eRscDataDB_X);

  // データベースタイプがeRscDataDB_Xの場合
  target::EType result1 = t.set(123);
  EXPECT_EQ(result1, target::eType_B);
  EXPECT_EQ(singletonB::getIntance()->getNum(), 123);  // 正しくデータが設定されているか確認

  // rscクラスのデータベースタイプを設定
  rsc::setDataDBType(rsc::eRscDataDB_Y);

  // データベースタイプがeRscDataDB_Yの場合
  target::EType result2 = t.set(456);
  EXPECT_EQ(result2, target::eType_C);
  EXPECT_EQ(singletonC::getIntance()->getNum(), 456);  // 正しくデータが設定されているか確認

  // rscクラスのデータベースタイプを設定
  rsc::setDataDBType(rsc::eRscDataDB_Z);

  // データベースタイプがeRscDataDB_Zの場合
  target::EType result3 = t.set(789);
  EXPECT_EQ(result3, target::eType_C);
  EXPECT_EQ(singletonC::getIntance()->getNum(), 789);  // 正しくデータが設定されているか確認

  // rscクラスのデータベースタイプを設定
  rsc::setDataDBType(static_cast<rsc::EDataDBType>(rsc::eRscDataDB_Max + 1));

  // データベースタイプがeRscDataDB_Maxを超える場合
  target::EType result4 = t.set(999);
  EXPECT_EQ(result4, target::eType_UnKnown);
}

int main(int argc, char** argv) {
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
